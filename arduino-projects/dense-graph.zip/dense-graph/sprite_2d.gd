extends Node2D

var nodes = []
var node_radius = 30
var dragging_node = null
var node_connections = []
var groups = []
var num_groups = 1
var num_graphs = 1

func _ready():
	$"../1".visible = false
	$"../2".visible = false
	$"../3".visible = false
	$"../4".visible = false
	$"../5".visible = false
	$"../6".visible = false
	$LineEdit.visible = true
	randomize()
	for i in range(100):
		var node = Node2D.new()
		node.position = Vector2(randf_range(30, 1060), randf_range(30, 560))
		node.name = "Node" + str(i)
		add_child(node)
		nodes.append(node)

		# Draw a circle to represent each node
		var sprite = Sprite2D.new()
		sprite.texture = preload("res://circle.png")  # Add a small circle image or shape as a texture
		sprite.scale = Vector2(0.025, 0.025)
		node.add_child(sprite)

		# Make the node clickable
		node.set_process_input(true)

		# Create connections between nodes
		if i > 0:
			node_connections.append([nodes[i-1], node])

func _input(event):
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			for node in nodes:
				var dist = node.position.distance_to(event.position)
				if dist <= node_radius:
					dragging_node = node
					break

		elif event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
			dragging_node = null

	elif event is InputEventMouseMotion and dragging_node:
		dragging_node.position += event.relative
		queue_redraw()

func _draw():
	# Draw connections
	for connection in node_connections:
		var node1 = connection[0]
		var node2 = connection[1]
		draw_line(node1.position, node2.position, Color.SEA_GREEN, 2)
	
	# Draw group rectangles
	for i in range(groups.size()):
		var group = groups[i]
		var group_color = Color.from_hsv(i * 0.1, 1.0, 1.0, 0.8)


		# Calculate bounding box for the group
		var min_x = INF
		var min_y = INF
		var max_x = -INF
		var max_y = -INF

		for node in group:
			min_x = min(min_x, node.position.x)
			min_y = min(min_y, node.position.y)
			max_x = max(max_x, node.position.x)
			max_y = max(max_y, node.position.y)
			
		for node in group:
			draw_circle(node.position, node_radius, group_color)

# Trigger group creation when a line edit node is updated
func _on_line_edit_text_submitted(new_text):
	num_groups = int(new_text)
	num_graphs = int(new_text)
	create_groups()
	create_graphs()

func create_graphs():
	$LineEdit.visible = false
	if num_graphs == 2:
		$"../1".visible = true
		$"../2".visible = true
	if num_graphs == 3:
		$"../1".visible = true
		$"../2".visible = true
		$"../3".visible = true
	if num_graphs == 4:
		$"../1".visible = true
		$"../2".visible = true
		$"../3".visible = true
		$"../4".visible = true
	if num_graphs == 5:
		$"../1".visible = true
		$"../2".visible = true
		$"../3".visible = true
		$"../4".visible = true
		$"../5".visible = true
	if num_graphs == 6:
		$"../1".visible = true
		$"../2".visible = true
		$"../3".visible = true
		$"../4".visible = true
		$"../5".visible = true
		$"../6".visible = true
		
func create_groups():
	# Clear the previous groups
	groups.clear()

	# Ensure that we don't have more groups than nodes
	if num_groups > nodes.size():
		num_groups = nodes.size()

	# Create a copy of nodes list to avoid modifying the original list while iterating
	var available_nodes = nodes.duplicate()

	# Greedy grouping: Create groups based on proximity
	for i in range(num_groups):
		var group = []
		var starting_node = available_nodes[0]  # Pick the first available node to start the group
		group.append(starting_node)
		available_nodes.erase(starting_node)  # Remove the node from available nodes

		# Add the closest nodes to the group
		while group.size() < int(nodes.size() / num_groups) and available_nodes.size() > 0:
			var closest_node = null
			var min_distance = INF

			# Find the closest node to any of the nodes already in the group
			for node in group:
				for other_node in available_nodes:
					var dist = node.position.distance_to(other_node.position)
					if dist < min_distance:
						min_distance = dist
						closest_node = other_node

			# Add the closest node to the group and remove it from available nodes
			group.append(closest_node)
			available_nodes.erase(closest_node)

		# Add the group to the groups list
		groups.append(group)

	# Print the groups
	print_groups()

# Function to print the groups
func print_groups():
	for i in range(groups.size()):
		var group = groups[i]
		var node_names = []
		for node in group:
			node_names.append(node.name)  # Collect node names instead of positions
		print("Group " + str(i + 1) + ": " + str(node_names))
